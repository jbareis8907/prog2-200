﻿// Program 2
// CIS 200-01
// Due: 3/10/18
// By: Z1907

// File: ReturnForm.cs
// This file creates a ReturnForm Dialog Box
// that allows the user to select a chekced out item
// and return it to the library
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class ReturnForm : Form
    {
        //Preconditiion: None
        //Postcondition: The ReturnForm GUI is displayed
        public ReturnForm(List<LibraryItem>itemList)
        {
            InitializeComponent();

            //LINQ to find checked out items
            var checkedOutItems =
            from item in itemList
            where item.IsCheckedOut()
            select item;

            foreach (var item in checkedOutItems)
            {
                returnComboBox.Items.Add(string.Format("{0},{1}{2}", item.Title, item.CallNumber, System.Environment.NewLine));
            }
        }

        internal int ReturnComboInput
        {
            //Precondition: None
            //Postcondition: The itemComboBox input is returned
            get { return returnComboBox.SelectedIndex; }
        }

        // Precondition:  Attempting to change focus from returnComboBox
        // Postcondition: If a value is selected, focus will change,
        //                else focus will remain and error provider message set
        private void returnComboBox_Validating(object sender, CancelEventArgs e)
        {
            if (returnComboBox.SelectedIndex < 0)
            {

                e.Cancel = true; // Stops focus changing process
                                 // Will NOT proceed to Validated event

                errorProvider1.SetError(returnComboBox, "Select an item!"); // Set error message

                returnComboBox.SelectAll(); // Select all text in itemComboBox to ease correction
            }
        }

        // Precondition:  returnComboBox_Validating succeeded
        // Postcondition: Any error message set for returnComboBox is cleared
        //                Focus is allowed to change
        private void returnComboBox_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(returnComboBox, ""); // Clears error message
        }


        // Precondition:  User has initiated click on returnCancelButton
        // Postcondition: If left-click, ReturnForm is dismissed with Cancel result
        private void returnCancelButton_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left) // Was it a left-click?
                this.DialogResult = DialogResult.Cancel;
        }

        // Precondition:  User has initiated click on returnOkButton
        // Postcondition: If all controls on form validate, ReturnForm is dismissed with OK result
        private void returnOkButton_Click(object sender, EventArgs e)
        {
            if (this.ValidateChildren())
                this.DialogResult = DialogResult.OK;
        }
    }
}
