﻿// Program 2
// CIS 200-01
// Due: 3/10/18
// By: Z1907

// File: PatronForm.cs
// This file creates a PatronForm Dialog Box
// that allows the user to enter their name and ID
// and save it to the Library
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class PatronForm : Form
    {
        public PatronForm()
        {
            InitializeComponent();
        }

        internal string NameInput
        {
            //Precondition: None
            //Postcondition: The name input is returned
            get { return nameTextBox.Text; }

            //Precondition: None
            //Postcondition: The name is set to the nameTextBox input
            set { nameTextBox.Text = value; }
        }

        internal string idInput
        {
            //Precondition: None
            //Postcondition: The ID input is returned
            get { return idTextBox.Text; }

            //Precondition: None
            //Postcondition: The ID is set to the idTextBox input
            set { idTextBox.Text = value; }
        }


        // Precondition:  Attempting to change focus from nameTextBox
        // Postcondition: If entered value is valid string, focus will change,
        //                else focus will remain and error provider message set
        private void nameTextBox_Validating(object sender, CancelEventArgs e)
        {
            //If value is blank or empty returns false
            if (string.IsNullOrWhiteSpace(nameTextBox.Text))

                e.Cancel = true; // Stops focus changing process
                                 // Will NOT proceed to Validated event

            errorProvider1.SetError(nameTextBox, "Enter a name!"); // Set error message

            nameTextBox.SelectAll(); // Select all text in nameTextBox to ease correction
        }

        // Precondition:  nameTextBox_Validating succeeded
        // Postcondition: Any error message set for nameTextBox is cleared
        //                Focus is allowed to change
        private void nameTextBox_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(nameTextBox, ""); // Clears error message
        }

        // Precondition:  Attempting to change focus from idTextBox
        // Postcondition: If entered value is valid string, focus will change,
        //                else focus will remain and error provider message set
        private void idTextBox_Validating(object sender, CancelEventArgs e)
        {
            //If value is blank or empty returns false
            if (string.IsNullOrWhiteSpace(idTextBox.Text))

                e.Cancel = true; // Stops focus changing process
                                 // Will NOT proceed to Validated event

            errorProvider2.SetError(idTextBox, "Enter an ID!"); // Set error message

            idTextBox.SelectAll(); // Select all text in nameTextBox to ease correction
        }

        // Precondition:  idTextBox_Validating succeeded
        // Postcondition: Any error message set for idTextBox is cleared
        //                Focus is allowed to change
        private void idTextBox_Validated(object sender, EventArgs e)
        {
            errorProvider2.SetError(idTextBox, ""); // Clears error message
        }

        // Precondition:  User has initiated click on patronCancelButton
        // Postcondition: If left-click, PatronForm is dismissed with Cancel result
        private void patronCancelButton_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left) // Was it a left-click?
                this.DialogResult = DialogResult.Cancel;
        }

        // Precondition:  User has initiated click on patronOkButton
        // Postcondition: If all controls on form validate, PatronForm is dismissed with OK result
        private void patronOkButton_Click(object sender, EventArgs e)
        {
             if (this.ValidateChildren())
                this.DialogResult = DialogResult.OK;
        }

    }
}
