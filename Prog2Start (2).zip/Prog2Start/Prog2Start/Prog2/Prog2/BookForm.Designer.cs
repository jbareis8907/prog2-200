﻿namespace LibraryItems
{
    partial class BookForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.titleLabel = new System.Windows.Forms.Label();
            this.publisherLabel = new System.Windows.Forms.Label();
            this.copyrightLabel = new System.Windows.Forms.Label();
            this.loanPeriodLabel = new System.Windows.Forms.Label();
            this.callNumberLabel = new System.Windows.Forms.Label();
            this.authorLabel = new System.Windows.Forms.Label();
            this.titleTextBox = new System.Windows.Forms.TextBox();
            this.publisherTextBox = new System.Windows.Forms.TextBox();
            this.copyrightTextBox = new System.Windows.Forms.TextBox();
            this.loanPeriodTextBox = new System.Windows.Forms.TextBox();
            this.callNumberTextBox = new System.Windows.Forms.TextBox();
            this.authorTextBox = new System.Windows.Forms.TextBox();
            this.bookOkButton = new System.Windows.Forms.Button();
            this.bookCancelButton = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider3 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider4 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider5 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider6 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider6)).BeginInit();
            this.SuspendLayout();
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.Location = new System.Drawing.Point(95, 40);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(42, 20);
            this.titleLabel.TabIndex = 0;
            this.titleLabel.Text = "Title:";
            // 
            // publisherLabel
            // 
            this.publisherLabel.AutoSize = true;
            this.publisherLabel.Location = new System.Drawing.Point(59, 91);
            this.publisherLabel.Name = "publisherLabel";
            this.publisherLabel.Size = new System.Drawing.Size(78, 20);
            this.publisherLabel.TabIndex = 1;
            this.publisherLabel.Text = "Publisher:";
            // 
            // copyrightLabel
            // 
            this.copyrightLabel.AutoSize = true;
            this.copyrightLabel.Location = new System.Drawing.Point(57, 142);
            this.copyrightLabel.Name = "copyrightLabel";
            this.copyrightLabel.Size = new System.Drawing.Size(80, 20);
            this.copyrightLabel.TabIndex = 2;
            this.copyrightLabel.Text = "Copyright:";
            // 
            // loanPeriodLabel
            // 
            this.loanPeriodLabel.AutoSize = true;
            this.loanPeriodLabel.Location = new System.Drawing.Point(39, 193);
            this.loanPeriodLabel.Name = "loanPeriodLabel";
            this.loanPeriodLabel.Size = new System.Drawing.Size(98, 20);
            this.loanPeriodLabel.TabIndex = 3;
            this.loanPeriodLabel.Text = "Loan Period:";
            // 
            // callNumberLabel
            // 
            this.callNumberLabel.AutoSize = true;
            this.callNumberLabel.Location = new System.Drawing.Point(38, 244);
            this.callNumberLabel.Name = "callNumberLabel";
            this.callNumberLabel.Size = new System.Drawing.Size(99, 20);
            this.callNumberLabel.TabIndex = 4;
            this.callNumberLabel.Text = "Call Number:";
            // 
            // authorLabel
            // 
            this.authorLabel.AutoSize = true;
            this.authorLabel.Location = new System.Drawing.Point(76, 295);
            this.authorLabel.Name = "authorLabel";
            this.authorLabel.Size = new System.Drawing.Size(61, 20);
            this.authorLabel.TabIndex = 5;
            this.authorLabel.Text = "Author:";
            // 
            // titleTextBox
            // 
            this.titleTextBox.Location = new System.Drawing.Point(143, 37);
            this.titleTextBox.Name = "titleTextBox";
            this.titleTextBox.Size = new System.Drawing.Size(100, 26);
            this.titleTextBox.TabIndex = 6;
            this.titleTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.titleTextBox_Validating);
            this.titleTextBox.Validated += new System.EventHandler(this.titleTextBox_Validated);
            // 
            // publisherTextBox
            // 
            this.publisherTextBox.Location = new System.Drawing.Point(143, 88);
            this.publisherTextBox.Name = "publisherTextBox";
            this.publisherTextBox.Size = new System.Drawing.Size(100, 26);
            this.publisherTextBox.TabIndex = 7;
            this.publisherTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.publisherTextBox_Validating);
            this.publisherTextBox.Validated += new System.EventHandler(this.publisherTextBox_Validated);
            // 
            // copyrightTextBox
            // 
            this.copyrightTextBox.Location = new System.Drawing.Point(143, 139);
            this.copyrightTextBox.Name = "copyrightTextBox";
            this.copyrightTextBox.Size = new System.Drawing.Size(100, 26);
            this.copyrightTextBox.TabIndex = 8;
            this.copyrightTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.copyrightTextBox_Validating);
            this.copyrightTextBox.Validated += new System.EventHandler(this.copyrightTextBox_Validated);
            // 
            // loanPeriodTextBox
            // 
            this.loanPeriodTextBox.Location = new System.Drawing.Point(143, 190);
            this.loanPeriodTextBox.Name = "loanPeriodTextBox";
            this.loanPeriodTextBox.Size = new System.Drawing.Size(100, 26);
            this.loanPeriodTextBox.TabIndex = 9;
            this.loanPeriodTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.loanPeriodTextBox_Validating);
            this.loanPeriodTextBox.Validated += new System.EventHandler(this.loanPeriodTextBox_Validated);
            // 
            // callNumberTextBox
            // 
            this.callNumberTextBox.Location = new System.Drawing.Point(143, 241);
            this.callNumberTextBox.Name = "callNumberTextBox";
            this.callNumberTextBox.Size = new System.Drawing.Size(100, 26);
            this.callNumberTextBox.TabIndex = 10;
            this.callNumberTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.callNumberTextBox_Validating);
            this.callNumberTextBox.Validated += new System.EventHandler(this.callNumberTextBox_Validated);
            // 
            // authorTextBox
            // 
            this.authorTextBox.Location = new System.Drawing.Point(143, 292);
            this.authorTextBox.Name = "authorTextBox";
            this.authorTextBox.Size = new System.Drawing.Size(100, 26);
            this.authorTextBox.TabIndex = 11;
            this.authorTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.authorTextBox_Validating);
            this.authorTextBox.Validated += new System.EventHandler(this.authorTextBox_Validated);
            // 
            // bookOkButton
            // 
            this.bookOkButton.Location = new System.Drawing.Point(28, 344);
            this.bookOkButton.Name = "bookOkButton";
            this.bookOkButton.Size = new System.Drawing.Size(109, 35);
            this.bookOkButton.TabIndex = 12;
            this.bookOkButton.Text = "OK";
            this.bookOkButton.UseVisualStyleBackColor = true;
            this.bookOkButton.Click += new System.EventHandler(this.bookOkButton_Click);
            // 
            // bookCancelButton
            // 
            this.bookCancelButton.Location = new System.Drawing.Point(156, 344);
            this.bookCancelButton.Name = "bookCancelButton";
            this.bookCancelButton.Size = new System.Drawing.Size(109, 35);
            this.bookCancelButton.TabIndex = 13;
            this.bookCancelButton.Text = "Cancel";
            this.bookCancelButton.UseVisualStyleBackColor = true;
            this.bookCancelButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.bookCancelButton_MouseDown);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            this.errorProvider2.ContainerControl = this;
            // 
            // errorProvider3
            // 
            this.errorProvider3.ContainerControl = this;
            // 
            // errorProvider4
            // 
            this.errorProvider4.ContainerControl = this;
            // 
            // errorProvider5
            // 
            this.errorProvider5.ContainerControl = this;
            // 
            // errorProvider6
            // 
            this.errorProvider6.ContainerControl = this;
            // 
            // BookForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(364, 405);
            this.Controls.Add(this.bookCancelButton);
            this.Controls.Add(this.bookOkButton);
            this.Controls.Add(this.authorTextBox);
            this.Controls.Add(this.callNumberTextBox);
            this.Controls.Add(this.loanPeriodTextBox);
            this.Controls.Add(this.copyrightTextBox);
            this.Controls.Add(this.publisherTextBox);
            this.Controls.Add(this.titleTextBox);
            this.Controls.Add(this.authorLabel);
            this.Controls.Add(this.callNumberLabel);
            this.Controls.Add(this.loanPeriodLabel);
            this.Controls.Add(this.copyrightLabel);
            this.Controls.Add(this.publisherLabel);
            this.Controls.Add(this.titleLabel);
            this.Name = "BookForm";
            this.Text = "Book Form";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider6)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.Label publisherLabel;
        private System.Windows.Forms.Label copyrightLabel;
        private System.Windows.Forms.Label loanPeriodLabel;
        private System.Windows.Forms.Label callNumberLabel;
        private System.Windows.Forms.Label authorLabel;
        private System.Windows.Forms.TextBox titleTextBox;
        private System.Windows.Forms.TextBox publisherTextBox;
        private System.Windows.Forms.TextBox copyrightTextBox;
        private System.Windows.Forms.TextBox loanPeriodTextBox;
        private System.Windows.Forms.TextBox callNumberTextBox;
        private System.Windows.Forms.TextBox authorTextBox;
        private System.Windows.Forms.Button bookOkButton;
        private System.Windows.Forms.Button bookCancelButton;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ErrorProvider errorProvider2;
        private System.Windows.Forms.ErrorProvider errorProvider3;
        private System.Windows.Forms.ErrorProvider errorProvider4;
        private System.Windows.Forms.ErrorProvider errorProvider5;
        private System.Windows.Forms.ErrorProvider errorProvider6;
    }
}

