﻿// Program 2
// CIS 200-01
// Due: 3/10/18
// By: Z1907

// File: CheckoutForm.cs
// This file creates a CheckoutForm Dialog Box
// that allows the user to select an item to checkout
// from the library
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class CheckoutForm : Form
    {

        //Preconditiion: None
        //Postcondition: The CheckoutForm GUI is displayed
        public CheckoutForm(List<LibraryItem>itemList, List<LibraryPatron>patronList)
        {
            InitializeComponent();

            foreach (var item in itemList) //Steps through item list
            {
                itemComboBox.Items.Add(string.Format("{0}, {1}{2}", item.Title, item.CallNumber, System.Environment.NewLine));
            }

            foreach (var patron in patronList)
            {
                patronComboBox.Items.Add(string.Format("{0}, {1}{2}", patron.PatronName, patron.PatronID, System.Environment.NewLine));
            }
        }

        internal int ItemComboInput
        {
            //Precondition: None
            //Postcondition: The itemComboBox input is returned
            get { return itemComboBox.SelectedIndex; }
        }

        internal int PatronComboInput
        {
            //Precondition: None
            //Postcondition: The patronComboBox input is returned
            get { return patronComboBox.SelectedIndex; }
        }

        
        // Precondition:  Attempting to change focus from itemComboBox
        // Postcondition: If a value is selected, focus will change,
        //                else focus will remain and error provider message set
        private void itemComboBox_Validating(object sender, CancelEventArgs e)
        {
            if(itemComboBox.SelectedIndex < 0)
            {

                e.Cancel = true; // Stops focus changing process
                                 // Will NOT proceed to Validated event

                errorProvider1.SetError(itemComboBox, "Select an item!"); // Set error message

                itemComboBox.SelectAll(); // Select all text in itemComboBox to ease correction
            }
        }

        // Precondition:  itemComboBox_Validating succeeded
        // Postcondition: Any error message set for itemComboBox is cleared
        //                Focus is allowed to change
        private void itemComboBox_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(itemComboBox, ""); // Clears error message
        }

        // Precondition:  Attempting to change focus from patronComboBox
        // Postcondition: If a value is selected, focus will change,
        //                else focus will remain and error provider message set
        private void patronComboBox_Validating(object sender, CancelEventArgs e)
        {
            if (patronComboBox.SelectedIndex < 0)
            {

                e.Cancel = true; // Stops focus changing process
                                 // Will NOT proceed to Validated event

                errorProvider2.SetError(patronComboBox, "Select a patron!"); // Set error message

                patronComboBox.SelectAll(); // Select all text in itemComboBox to ease correction
            }
        }


        // Precondition:  patronComboBox_Validating succeeded
        // Postcondition: Any error message set for patronComboBox is cleared
        //                Focus is allowed to change
        private void patronComboBox_Validated(object sender, EventArgs e)
        {
            errorProvider2.SetError(patronComboBox, ""); // Clears error message
        }

        // Precondition:  User has initiated click on checkoutCancelButton
        // Postcondition: If left-click, CheckoutForm is dismissed with Cancel result
        private void checkOutCancelButton_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left) // Was it a left-click?
                this.DialogResult = DialogResult.Cancel;
        }

        // Precondition:  User has initiated click on checkoutOkButton
        // Postcondition: If all controls on form validate, CheckoutForm is dismissed with OK result
        private void checkOutOkButton_Click(object sender, EventArgs e)
        {
            if (this.ValidateChildren())
                this.DialogResult = DialogResult.OK;
        }
    }
}
