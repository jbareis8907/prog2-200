﻿// Program 2
// CIS 200-01
// Due: 3/10/18
// By: Z1907

// File: BookForm.cs
// This file creates a BookForm Dialog Box
// that allows the user to enter information about a book
// and save to the library

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class BookForm : Form
    {
        public BookForm()
        {
            InitializeComponent();
        }

        internal string TitleInput
        {
            //Precondition: None
            //Postcondition: The title input is returned
            get { return titleTextBox.Text; }

            //Precondition: None
            //Postcondition: The title is set to the titleTextBox input
            set { titleTextBox.Text = value; }
        }

        internal string PublisherInput
        {
            //Precondition: None
            //Postcondition: The publisher input is returned
            get { return publisherTextBox.Text; }

            //Precondition: None
            //Postcondition: The publisher is set to the publisherTextBox input
            set { publisherTextBox.Text = value; }
        }

        internal string CopyrightInput
        {
            //Preconditon: None
            //Postcondition: The copyright year input is returned
            get { return copyrightTextBox.Text; }

            //Precondition: None
            //Postconditon: The copyright year is set to the copyrightTextBox input
            set { copyrightTextBox.Text = value; }
        }

        internal string LoanPeriodInput
        {
            //Precondition: None
            //Postcondition: The loan period input is returned
            get { return loanPeriodTextBox.Text; }

            //Precondition: None
            //Postconditon: The loan period is set to the loanPeriodTextBox input
            set { loanPeriodTextBox.Text = value; }
        }

        internal string CallNumberInput
        {
            //Precondition: None
            //Postcondition: The call number input is returned
            get { return callNumberTextBox.Text; }

            //Precondition: None
            //Postconditon: The call number is set to the callNumberTextBox input
            set { callNumberTextBox.Text = value; }
        }

        internal string AuthorInput
        {
            //Precondition: None
            //Postcondition: The author input is returned
            get { return authorTextBox.Text; }

            //Precondition: None
            //Postconditon: The author is set to the authorTextBox input
            set { authorTextBox.Text = value; }
        }

        // Precondition:  Attempting to change focus from titleTextBox
        // Postcondition: If entered value is valid string, focus will change,
        //                else focus will remain and error provider message set
        private void titleTextBox_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(titleTextBox.Text))

                e.Cancel = true; // Stops focus changing process
                                 // Will NOT proceed to Validated event

            errorProvider1.SetError(titleTextBox, "Enter a title!"); // Set error message

            titleTextBox.SelectAll(); // Select all text in titleTextBox to ease correction
        }

        // Precondition:  titleTextBox_Validating succeeded
        // Postcondition: Any error message set for titleTextBox is cleared
        //                Focus is allowed to change
        private void titleTextBox_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(titleTextBox, ""); // Clears error message
        }

        // Precondition:  Attempting to change focus from publisherTextBox
        // Postcondition: If entered value is valid string, focus will change,
        //                else focus will remain and error provider message set
        private void publisherTextBox_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(publisherTextBox.Text))

                e.Cancel = true; // Stops focus changing process
                                 // Will NOT proceed to Validated event

            errorProvider2.SetError(publisherTextBox, "Enter a publisher!"); // Set error message

            publisherTextBox.SelectAll(); // Select all text in inputTxt to ease correction
        }

        // Precondition:  publisherTextBox_Validating succeeded
        // Postcondition: Any error message set for publisherTextBox is cleared
        //                Focus is allowed to change
        private void publisherTextBox_Validated(object sender, EventArgs e)
        {
            errorProvider2.SetError(publisherTextBox, ""); // Clears error message
        }

        // Precondition:  Attempting to change focus from copyrightTextBox
        // Postcondition: If entered value is valid int, focus will change,
        //                else focus will remain and error provider message set
        private void copyrightTextBox_Validating(object sender, CancelEventArgs e)
        {
            int copyrightNumber; // Value entered into copyrightTextBox

            // Will try to parse text as int
            // If fails, TryParse returns false
            // If succeeds, TryParse returns true and number stores parsed value
            if (!int.TryParse(copyrightTextBox.Text, out copyrightNumber))
            {
                e.Cancel = true; // Stops focus changing process
                                 // Will NOT proceed to Validated event

                errorProvider3.SetError(copyrightTextBox, "Enter a copyright year!"); // Set error message

                copyrightTextBox.SelectAll(); // Select all text in copyrightTextBox to ease correction
            }
            else
            {
                if (copyrightNumber < 0)
                {
                    e.Cancel = true; // Stops focus changing process
                    // Will NOT proceed to Validated event

                    errorProvider3.SetError(copyrightTextBox, "Enter a copyright year!"); // Set error message

                    copyrightTextBox.SelectAll(); // Select all text in inputTxt to ease correction
                }
            }
        }

        // Precondition:  copyrightTextBox_Validating succeeded
        // Postcondition: Any error message set for copyrightTextBox is cleared
        //                Focus is allowed to change
        private void copyrightTextBox_Validated(object sender, EventArgs e)
        {
            errorProvider3.SetError(copyrightTextBox, ""); // Clears error message
        }

        // Precondition:  Attempting to change focus from loanPeriodTextBox
        // Postcondition: If entered value is valid int, focus will change,
        //                else focus will remain and error provider message set
        private void loanPeriodTextBox_Validating(object sender, CancelEventArgs e)
        {
            int loanPeriodNumber; // Value entered into loanPeriodTextBox

            // Will try to parse text as int
            // If fails, TryParse returns false
            // If succeeds, TryParse returns true and number stores parsed value
            if (!int.TryParse(loanPeriodTextBox.Text, out loanPeriodNumber))
            {
                e.Cancel = true; // Stops focus changing process
                                 // Will NOT proceed to Validated event

                errorProvider4.SetError(loanPeriodTextBox, "Enter a loan period!"); // Set error message

                loanPeriodTextBox.SelectAll(); // Select all text in loanPeriodTextBox to ease correction
            }
            else
            {
                if (loanPeriodNumber < 0)
                {
                    e.Cancel = true; // Stops focus changing process
                    // Will NOT proceed to Validated event

                    errorProvider4.SetError(loanPeriodTextBox, "Enter a loan period!"); // Set error message

                    loanPeriodTextBox.SelectAll(); // Select all text in loanPeriodTextBox to ease correction
                }
            }
        }

        // Precondition:  loanPeriodTextBox_Validating succeeded
        // Postcondition: Any error message set for loanPeriodTextBox is cleared
        //                Focus is allowed to change
        private void loanPeriodTextBox_Validated(object sender, EventArgs e)
        {
            errorProvider4.SetError(loanPeriodTextBox, ""); // Clears error message

        }

        // Precondition:  Attempting to change focus from callNumberTextBox
        // Postcondition: If entered value is valid string, focus will change,
        //                else focus will remain and error provider message set
        private void callNumberTextBox_Validating(object sender, CancelEventArgs e)
        {
            //If value is blank or empty returns false
            if (string.IsNullOrWhiteSpace(callNumberTextBox.Text))

                e.Cancel = true; // Stops focus changing process
                                 // Will NOT proceed to Validated event

            errorProvider5.SetError(callNumberTextBox, "Enter a call number!"); // Set error message

            callNumberTextBox.SelectAll(); // Select all text in callNumberTextBox to ease correction
        }

        // Precondition:  callNumberTextBox_Validating succeeded
        // Postcondition: Any error message set for callNumberTextBox is cleared
        //                Focus is allowed to change
        private void callNumberTextBox_Validated(object sender, EventArgs e)
        {
            errorProvider5.SetError(callNumberTextBox, ""); // Clears error message
        }

        // Precondition:  Attempting to change focus from authorTextBox
        // Postcondition: If entered value is valid string, focus will change,
        //                else focus will remain and error provider message set
        private void authorTextBox_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(authorTextBox.Text))

                e.Cancel = true; // Stops focus changing process
                                 // Will NOT proceed to Validated event

            errorProvider6.SetError(authorTextBox, "Enter an author!"); // Set error message
        }

        // Precondition:  authorTextBox_Validating succeeded
        // Postcondition: Any error message set for authorTextBox is cleared
        //                Focus is allowed to change
        private void authorTextBox_Validated(object sender, EventArgs e)
        {
            errorProvider6.SetError(authorTextBox, ""); // Clears error message
        }


        // Precondition:  User has initiated click on bookCancelButton
        // Postcondition: If left-click, BookForm is dismissed with Cancel result
        private void bookCancelButton_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left) // Was it a left-click?
                this.DialogResult = DialogResult.Cancel;
        }

        // Precondition:  User has initiated click on bookOkButton
        // Postcondition: If all controls on form validate, BookForm is dismissed with OK result
        private void bookOkButton_Click(object sender, EventArgs e)
        {
            if (this.ValidateChildren())
                this.DialogResult = DialogResult.OK;
        }
    }
}
