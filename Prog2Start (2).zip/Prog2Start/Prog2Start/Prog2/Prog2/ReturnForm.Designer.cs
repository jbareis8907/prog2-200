﻿namespace LibraryItems
{
    partial class ReturnForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.returnLabel = new System.Windows.Forms.Label();
            this.returnComboBox = new System.Windows.Forms.ComboBox();
            this.returnOkButton = new System.Windows.Forms.Button();
            this.returnCancelButton = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // returnLabel
            // 
            this.returnLabel.AutoSize = true;
            this.returnLabel.Location = new System.Drawing.Point(60, 62);
            this.returnLabel.Name = "returnLabel";
            this.returnLabel.Size = new System.Drawing.Size(94, 20);
            this.returnLabel.TabIndex = 0;
            this.returnLabel.Text = "Select Item:";
            // 
            // returnComboBox
            // 
            this.returnComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.returnComboBox.FormattingEnabled = true;
            this.returnComboBox.Location = new System.Drawing.Point(64, 100);
            this.returnComboBox.Name = "returnComboBox";
            this.returnComboBox.Size = new System.Drawing.Size(263, 28);
            this.returnComboBox.TabIndex = 1;
            this.returnComboBox.Validating += new System.ComponentModel.CancelEventHandler(this.returnComboBox_Validating);
            this.returnComboBox.Validated += new System.EventHandler(this.returnComboBox_Validated);
            // 
            // returnOkButton
            // 
            this.returnOkButton.Location = new System.Drawing.Point(64, 199);
            this.returnOkButton.Name = "returnOkButton";
            this.returnOkButton.Size = new System.Drawing.Size(121, 39);
            this.returnOkButton.TabIndex = 2;
            this.returnOkButton.Text = "OK";
            this.returnOkButton.UseVisualStyleBackColor = true;
            this.returnOkButton.Click += new System.EventHandler(this.returnOkButton_Click);
            // 
            // returnCancelButton
            // 
            this.returnCancelButton.Location = new System.Drawing.Point(206, 199);
            this.returnCancelButton.Name = "returnCancelButton";
            this.returnCancelButton.Size = new System.Drawing.Size(121, 39);
            this.returnCancelButton.TabIndex = 3;
            this.returnCancelButton.Text = "Cancel";
            this.returnCancelButton.UseVisualStyleBackColor = true;
            this.returnCancelButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.returnCancelButton_MouseDown);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // ReturnForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(386, 321);
            this.Controls.Add(this.returnCancelButton);
            this.Controls.Add(this.returnOkButton);
            this.Controls.Add(this.returnComboBox);
            this.Controls.Add(this.returnLabel);
            this.Name = "ReturnForm";
            this.Text = "ReturnForm";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label returnLabel;
        private System.Windows.Forms.ComboBox returnComboBox;
        private System.Windows.Forms.Button returnOkButton;
        private System.Windows.Forms.Button returnCancelButton;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}