﻿namespace LibraryItems
{
    partial class CheckoutForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.selectItemLabel = new System.Windows.Forms.Label();
            this.selectPatronLabel = new System.Windows.Forms.Label();
            this.itemComboBox = new System.Windows.Forms.ComboBox();
            this.patronComboBox = new System.Windows.Forms.ComboBox();
            this.checkOutOkButton = new System.Windows.Forms.Button();
            this.checkOutCancelButton = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider2 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).BeginInit();
            this.SuspendLayout();
            // 
            // selectItemLabel
            // 
            this.selectItemLabel.AutoSize = true;
            this.selectItemLabel.Location = new System.Drawing.Point(60, 28);
            this.selectItemLabel.Name = "selectItemLabel";
            this.selectItemLabel.Size = new System.Drawing.Size(98, 20);
            this.selectItemLabel.TabIndex = 0;
            this.selectItemLabel.Text = "Select Item: ";
            // 
            // selectPatronLabel
            // 
            this.selectPatronLabel.AutoSize = true;
            this.selectPatronLabel.Location = new System.Drawing.Point(60, 175);
            this.selectPatronLabel.Name = "selectPatronLabel";
            this.selectPatronLabel.Size = new System.Drawing.Size(113, 20);
            this.selectPatronLabel.TabIndex = 1;
            this.selectPatronLabel.Text = "Select: Patron:";
            // 
            // itemComboBox
            // 
            this.itemComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.itemComboBox.FormattingEnabled = true;
            this.itemComboBox.Location = new System.Drawing.Point(64, 51);
            this.itemComboBox.Name = "itemComboBox";
            this.itemComboBox.Size = new System.Drawing.Size(306, 28);
            this.itemComboBox.TabIndex = 2;
            this.itemComboBox.Validating += new System.ComponentModel.CancelEventHandler(this.itemComboBox_Validating);
            this.itemComboBox.Validated += new System.EventHandler(this.itemComboBox_Validated);
            // 
            // patronComboBox
            // 
            this.patronComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.patronComboBox.FormattingEnabled = true;
            this.patronComboBox.Location = new System.Drawing.Point(64, 198);
            this.patronComboBox.Name = "patronComboBox";
            this.patronComboBox.Size = new System.Drawing.Size(306, 28);
            this.patronComboBox.TabIndex = 3;
            this.patronComboBox.Validating += new System.ComponentModel.CancelEventHandler(this.patronComboBox_Validating);
            this.patronComboBox.Validated += new System.EventHandler(this.patronComboBox_Validated);
            // 
            // checkOutOkButton
            // 
            this.checkOutOkButton.Location = new System.Drawing.Point(89, 292);
            this.checkOutOkButton.Name = "checkOutOkButton";
            this.checkOutOkButton.Size = new System.Drawing.Size(119, 37);
            this.checkOutOkButton.TabIndex = 4;
            this.checkOutOkButton.Text = "OK";
            this.checkOutOkButton.UseVisualStyleBackColor = true;
            this.checkOutOkButton.Click += new System.EventHandler(this.checkOutOkButton_Click);
            // 
            // checkOutCancelButton
            // 
            this.checkOutCancelButton.Location = new System.Drawing.Point(223, 292);
            this.checkOutCancelButton.Name = "checkOutCancelButton";
            this.checkOutCancelButton.Size = new System.Drawing.Size(119, 37);
            this.checkOutCancelButton.TabIndex = 5;
            this.checkOutCancelButton.Text = "Cancel";
            this.checkOutCancelButton.UseVisualStyleBackColor = true;
            this.checkOutCancelButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.checkOutCancelButton_MouseDown);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            this.errorProvider2.ContainerControl = this;
            // 
            // CheckoutForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(430, 368);
            this.Controls.Add(this.checkOutCancelButton);
            this.Controls.Add(this.checkOutOkButton);
            this.Controls.Add(this.patronComboBox);
            this.Controls.Add(this.itemComboBox);
            this.Controls.Add(this.selectPatronLabel);
            this.Controls.Add(this.selectItemLabel);
            this.Name = "CheckoutForm";
            this.Text = "Check Out";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label selectItemLabel;
        private System.Windows.Forms.Label selectPatronLabel;
        private System.Windows.Forms.ComboBox itemComboBox;
        private System.Windows.Forms.ComboBox patronComboBox;
        private System.Windows.Forms.Button checkOutOkButton;
        private System.Windows.Forms.Button checkOutCancelButton;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ErrorProvider errorProvider2;
    }
}