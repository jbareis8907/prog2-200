﻿// Program 2
// CIS 200-01
// Due: 3/10/18
// By: Z1907

// File: Prog2Form.cs
// This file creates a Prog2Form that serves as
// the main form for the application. It contains a toolstrip
// that will allow you to open other dialog boxes for saving information
// to the Library
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class Prog2Form : Form
    {
        private Library _lib; //The library
       
        //Precondition: None
        //Postcondition: The form's GUI is displayed and a list of items is added to the library
        public Prog2Form()
        {
            InitializeComponent();

            _lib = new Library(); //Create the library

            // Test data - Magic numbers allowed here
            _lib.AddLibraryBook("The Wright Guide to C#", "UofL Press", 2010, 14,
                "ZZ25 3G", "Andrew Wright");
            _lib.AddLibraryBook("Harriet Pooter", "Stealer Books", 2000, 21,
                "AB73 ZF", "IP Thief");
            _lib.AddLibraryMovie("Andrew's Super-Duper Movie", "UofL Movies", 2011, 7,
                "MM33 2D", 92.5, "Andrew L. Wright", LibraryMediaItem.MediaType.BLURAY,
                LibraryMovie.MPAARatings.PG);
            _lib.AddLibraryMovie("Pirates of the Carribean: The Curse of C#", "Disney Programming", 2012, 10,
                "MO93 4S", 122.5, "Steven Stealberg", LibraryMediaItem.MediaType.DVD, LibraryMovie.MPAARatings.G);
            _lib.AddLibraryMusic("C# - The Album", "UofL Music", 2014, 14,
                "CD44 4Z", 84.3, "Dr. A", LibraryMediaItem.MediaType.CD, 10);
            _lib.AddLibraryMusic("The Sounds of Programming", "Soundproof Music", 1996, 21,
                "VI64 1Z", 65.0, "Cee Sharpe", LibraryMediaItem.MediaType.VINYL, 12);
            _lib.AddLibraryJournal("Journal of C# Goodness", "UofL Journals", 2000, 14,
                "JJ12 7M", 1, 2, "Information Systems", "Andrew Wright");
            _lib.AddLibraryJournal("Journal of VB Goodness", "UofL Journals", 2008, 14,
                "JJ34 3F", 8, 4, "Information Systems", "Alexander Williams");
            _lib.AddLibraryMagazine("C# Monthly", "UofL Mags", 2016, 14,
                "MA53 9A", 16, 7);
            _lib.AddLibraryMagazine("C# Monthly", "UofL Mags", 2016, 14,
                "MA53 9B", 16, 8);
            _lib.AddLibraryMagazine("C# Monthly", "UofL Mags", 2016, 14,
                "MA53 9C", 16, 9);
            _lib.AddLibraryMagazine("     VB Magazine    ", "    UofL Mags   ", 2018, 14,
                "MA21 5V", 1, 1);

            // Add patrons
            _lib.AddPatron("Ima Reader", "12345");
            _lib.AddPatron("Jane Doe", "11223");
            _lib.AddPatron("   John Smith   ", "   654321   ");
            _lib.AddPatron("James T. Kirk", "98765");
            _lib.AddPatron("Jean-Luc Picard", "33456");
        }

        //Precondition: The aboutToolStripMenuItem1 has been clicked
        //Postcondition: Grading ID, Program number, and due date are displayed in message box
        private void aboutToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Z1907" + System.Environment.NewLine + "Program 2" + System.Environment.NewLine + "3-7-18");
        }

        //Precondition: The exitToolStripMenuItem has been clicked
        //Postcondition: The application closes
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //Precondition: The patronListToolStripMenuItem has been clicked
        //Postcondition: The patron list is displayed in the textbox
        private void patronListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            outputTextBox.Clear(); //Clear the textbox

            outputTextBox.Text = _lib.GetPatronCount().ToString(); //Get patron count

            outputTextBox.AppendText(System.Environment.NewLine); //New line

            foreach (LibraryPatron item in _lib.GetPatronsList()) //Step through patron list
            {
                outputTextBox.AppendText(item.ToString() + System.Environment.NewLine); //Add to string

                outputTextBox.AppendText(System.Environment.NewLine); //New Line
            }
        }

        //Precondition: The itemListToolStripMenuItem has been clicked
        //Postcondition: The item list is displayed in the textbox
        private void itemListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            outputTextBox.Clear(); //Clear the textbox

            outputTextBox.Text = _lib.GetItemCount().ToString(); //Get item count

            outputTextBox.AppendText(System.Environment.NewLine); //New line

            foreach (LibraryItem item in _lib.GetItemsList()) //Step through item list
            {
                outputTextBox.AppendText(item.ToString() + System.Environment.NewLine); //Add to string

                outputTextBox.AppendText(System.Environment.NewLine); //New line
            }
        }

        //Precondition: The checkedOutItemsToolStripMenuItem has been clicked
        //Postcondition: The checked out items list is displayed in the textbox
        private void checkedOutItemsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            outputTextBox.Clear(); //Clear the textbox

            outputTextBox.Text = _lib.GetItemCount().ToString(); //Get item count

            foreach (LibraryItem item in _lib.GetItemsList()) //Step through item list
            {
                if (item.IsCheckedOut()) //Checks to see if item is checked out
                {
                    outputTextBox.AppendText(item.ToString() + System.Environment.NewLine); //Add to string

                    outputTextBox.AppendText(System.Environment.NewLine); //New line
                }
            }
        }

        // Precondition:  The patronToolStripMenuItem has been clicked
        // Postcondition: A dialog box has been displayed prompting for
        //                a name and ID. If user submits, Library is updated
        private void patronToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PatronForm patronForm = new PatronForm(); // The dialog box form
            DialogResult result;                // Result from dialog - OK/Cancel?
            string patronName;                  // User's input from dialog box
            string patronID;                       // User's input (gather from dialog box)

            result = patronForm.ShowDialog(); // Show dialog box form - modal, waits for OK/Cancel
                                              // Even after user dismisses, the form still exists
                                              // and can be interacted with using methods/properties

            if (result == DialogResult.OK)  // Only update if user chose OK from dialog box
            {
                patronName = patronForm.NameInput;
                patronID = patronForm.idInput;
                _lib.AddPatron(patronName, patronID);
            }
        }

        // Precondition:  The bookToolStripMenuItem has been clicked
        // Postcondition: A dialog box has been displayed prompting for
        //                a title, publisher, copyright, loan period, call number,
        //                and author. If user submits, Library is updated
        private void bookToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BookForm bookForm = new BookForm(); // The dialog box form
            DialogResult result;                // Result from dialog - OK/Cancel?
            string title;                       // User's  title input (gather from dialog box)
            string publisher;                   // User's publisher input (gather from dialog box)
            int copyright;                      // User's publisher input (gather from dialog box)
            int loanPeriod;                     // User's publisher input (gather from dialog box)
            string callNumber;                  // User's publisher input (gather from dialog box)
            string author;                      // User's publisher input (gather from dialog box)

            result = bookForm.ShowDialog();   // Show dialog box form - modal, waits for OK/Cancel
                                              // Even after user dismisses, the form still exists
                                              // and can be interacted with using methods/properties

            if (result == DialogResult.OK)  // Only update if user chose OK from dialog box
            {
                title = bookForm.TitleInput;
                publisher = bookForm.PublisherInput;
                copyright = int.Parse(bookForm.CopyrightInput);
                loanPeriod = int.Parse(bookForm.LoanPeriodInput);
                callNumber = bookForm.CallNumberInput;
                author = bookForm.AuthorInput;
                _lib.AddLibraryBook(title, publisher, copyright, loanPeriod, callNumber, author);
            }
        }

        // Precondition:  The checkOutToolStripMenuItem has been clicked
        // Postcondition: A dialog box has been displayed prompting for
        //                a checked out item and patron. If user submits, Library is updated
        private void checkOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CheckoutForm checkoutForm = new CheckoutForm(_lib._items, _lib._patrons);
            DialogResult result;
            int item;
            int patron;

            result = checkoutForm.ShowDialog();

            if (result == DialogResult.OK)// Only update if user chose OK from dialog box
            {
                item = checkoutForm.ItemComboInput;
                patron = checkoutForm.PatronComboInput;
                _lib.CheckOut(item, patron);
            }
        }

        // Precondition:  The returnToolStripMenuItem has been clicked
        // Postcondition: A dialog box has been displayed prompting for
        //                a checked out item. If user submits, Library is updated
        private void returnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ReturnForm returnForm = new ReturnForm(_lib._items);
            DialogResult result;
            int item;

            result = returnForm.ShowDialog();


            if (result == DialogResult.OK)// Only update if user chose OK from dialog box
            {
                item = returnForm.ReturnComboInput;
                _lib.ReturnToShelf(item);
            }
        }
    }
}
